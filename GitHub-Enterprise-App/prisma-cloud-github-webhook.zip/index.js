const common_library = require('./lib/common-library')
const pull_request_handler = require('./lib/pull-request-handler')
const initial_install_handler = require('./lib/initial-installation-handler')
const { registerAuthRoutes } = require('auth-routes')
const request = require('request')
const { promisify } = require('util')
const post = promisify(request.post)
var octokit

/**
 * This is the main entrypoint to your Probot app
 * @param {import('probot').Application} app
 */
module.exports = app => {
  
  // this event is triggered when this app is installed or uninstalled on a repository
  app.on(['installation.created'], async context => {
    app.log('triggered first time installation')

    await common_library.sleep(180 * 1000); //3 mins

    await initial_install_handler(context)

  })

  app.on(['installation_repositories.added'], async context => {
    app.log('triggered repo additions')

    await initial_install_handler(context)

  })

  app.on(['installation.deleted', 'integration_installation.deleted'], async context => {
    app.log('triggered installation deletion')

    try {

      var gitHubAppId = context.payload.installation.app_id
      var gitHubInstallationId = context.payload.installation.id

      console.log('gitHubInstallationId : ' + gitHubInstallationId)
      console.log('gitHubAppId : ' + gitHubAppId)

      app.log('user who deleted the app: ' + context.payload.installation.account.login)

    } catch (e) {
      console.log(e)
    }
  })

  // this event is triggered when pull request is closed
  app.on('pull_request.closed', async context => {
    const pr = context.payload.pull_request
    const org = context.payload.pull_request.base.repo.owner.login
    const repo = context.payload.pull_request.base.repo.name
    const headSha = context.payload.pull_request.head.sha
    app.log('org' + org + 'repo' + repo + 'headSha' + headSha)
    const checks = await context.github.checks.listForRef(context.repo({
      ref: headSha,
      filter: 'latest'
    }))
    app.log(checks)
    if (checks.data.check_runs.length == 0 || checks.data.check_runs == undefined) {
      app.log('Merged with no standing checks')
    } else {
      app.log('Merged with standing checks')
    }
    app.log(checks.data.check_runs.length)
    app.log('Event triggered for merge pull request1')
  })

  // This event is triggered when pull request is opened or reopened
  app.on(['pull_request.opened', 'pull_request.reopened'], async context => {
    app.log('pull request opened')

    const octokit = await app.auth()
    const { data } = await octokit.apps.getAuthenticated()
    await pull_request_handler(context, data)
  })
}
