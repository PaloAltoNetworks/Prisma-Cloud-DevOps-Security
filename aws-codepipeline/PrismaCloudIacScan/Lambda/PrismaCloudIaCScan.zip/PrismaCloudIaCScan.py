import json
import boto3
import logging
import urllib
import os
from urllib.error import HTTPError
import requests

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
code_pipeline = boto3.client('codepipeline')


def find_artifact(event):
    try:
        object_key = event['CodePipeline.job']['data']['inputArtifacts'][0] \
            ['location']['s3Location']['objectKey']
        bucket = event['CodePipeline.job']['data']['inputArtifacts'][0] \
            ['location']['s3Location']['bucketName']

        return bucket, object_key

    except KeyError as err:
        raise KeyError("Couldn't get S3 object!\n%s", err)


def _get_user_parameters(job_data):
    try:
        configuration = job_data['actionConfiguration']['configuration']

        if ('UserParameters' not in configuration):
            return

        user_parameters = configuration['UserParameters']
        decoded_parameters = json.loads(user_parameters)
    except Exception as e:
        # We're expecting the user parameters to be encoded as JSON
        # so we can pass multiple values. If the JSON can't be decoded
        # then fail the job with a helpful message.
        raise Exception('UserParameters could not be decoded as JSON')
    return decoded_parameters


def _get_output_artifact_location(job_data):
    location = job_data['outputArtifacts'][0]['location']['s3Location']
    bucket = location['bucketName']
    key = location['objectKey']
    return bucket, key


def put_job_success(job, message):
    """Notify CodePipeline of a successful job

    Args:
        job: The CodePipeline job ID
        message: A message to be logged relating to the job status

    Raises:
        Exception: Any exception thrown by .put_job_success_result()

    """
    if (message is None):
        message = "Good job! Prisma Cloud did not detect any issues."
    print(message)
    #print('Putting job success')
    message = message[:2040]
    code_pipeline.put_job_success_result(jobId=job, executionDetails={"summary": message})


def put_job_failure(job, message):
    """Notify CodePipeline of a failed job

    Args:
        job: The CodePipeline job ID
        message: A message to be logged relating to the job status

    Raises:
        Exception: Any exception thrown by .put_job_failure_result()

    """
    print(message)
    #print('Putting job failure')
    code_pipeline.put_job_failure_result(jobId=job, failureDetails={'message': message, 'type': 'JobFailed'})


def decide_job_status(criteria, statsList, rules_matched, job_id, inputFlag):
    """
     Args: criteria -> Input failureCriteria for severity levels
           statsList -> API Response  combined severity level number list for high,medium,low
           rules_matched -> JSON response from API with rules policy , severity, id etc.
           job_id -> CodePipeline job request Id
     Based on Input criteria on severity level count compared with API response stats and Opertor provided in the user parameter,
     Job will be failed or succeeded with JSON failure details
    """
    h, m, l = 0, 0, 0

    operator = 'or'
    if 'High' in criteria:
        h = (criteria['High'])
    if 'Medium' in criteria:
        m = (criteria['Medium'])
    if 'Low' in criteria:
        l = (criteria['Low'])
    if 'Operator' in criteria:
        operator = criteria['Operator']
    failureMsg = """Prisma Cloud IaC scan failed with issues as security issues count (High: {0}, Medium: {1}, Low: {2}) meets or exceeds failure criteria (High: {3}, Medium: {4}, Low: {5})""".format(statsList[0], statsList[1], statsList[2], h, m, l)
    succeesWithIssues = """Prisma Cloud IaC scan succeeded with issues as security issues count (High: {0}, Medium: {1}, Low: {2}) below failure criteria (High: {3}, Medium: {4}, Low: {5})""".format( statsList[0], statsList[1], statsList[2], h, m, l)


    if (rules_matched is not None):
        if (inputFlag):
            if (operator == 'or') and (statsList[0] >= h or statsList[1] >= m or statsList[2] >= l):
                print(failureMsg)
                put_job_failure(job_id, json.dumps(rules_matched, indent=2))
            elif (operator == 'and') and (statsList[0] >= h and statsList[1] >= m and statsList[2] >= l):
                print(failureMsg)
                put_job_failure(job_id, json.dumps(rules_matched, indent=2))
            else:
                print(succeesWithIssues)
                put_job_success(job_id, json.dumps(rules_matched))
        else:
            put_job_success(job_id, json.dumps(rules_matched))
    else:
        print("Good job! Prisma Cloud did not detect any issues.")
        put_job_success(job_id, "Success with no issues.")



def getTokenFromLoginService(job_id, host, accessKey, secretKey):
    login_url = host + "/login"

    body = {
        "username": accessKey,
        "password": secretKey

    };
    res = urllib.request.Request(login_url, json.dumps(body).encode('utf-8'))
    res.add_header('Content-type', 'application/json')
    try:
        response = urllib.request.urlopen(res).read()  # .decode('utf-8')
        tokens = (json.loads(response)).get('token')

        return tokens


    except urllib.error.HTTPError as ex:
        print('Error code in HTTPErr: ', ex.code, ex.reason, ex.msg)
        if ex.code == 400 or ex.code == 401:
            print(
                "Invalid credentials please verify that API URL, Access Key and Secret Key in Prisma Cloud Extension environment settings are valid For details refer to https://docs.paloaltonetworks.com/prisma/prisma-cloud/prisma-cloud-admin/prisma-cloud-devops-security/use-the-prisma-cloud-extension-for-aws-codepipeline.html")
            put_job_failure(job_id, str(ex))
        if ex.code == 500:
            print(
                "Oops! Something went wrong, please try again or refer to documentation here documentation https://docs.paloaltonetworks.com/prisma/prisma-cloud/prisma-cloud-admin/prisma-cloud-devops-security/use-the-prisma-cloud-extension-for-aws-codepipeline.html")
            put_job_failure(job_id, str(ex))



def lambda_handler(event, context):
    print(event)
    try:

        job_id = event['CodePipeline.job']['id']
        print("jobID:", job_id)
        server_url = os.environ['Prisma_Cloud_API_URL']
        accesskey = os.environ['Access_Key']
        secretKey = os.environ['Secret_Key']

        job_data = event['CodePipeline.job']['data']
        params = _get_user_parameters(job_data)

        criteria = ''
        inputFlag = False
        tokens = getTokenFromLoginService(job_id, server_url, accesskey, secretKey);

        bucketName, obj = find_artifact(event)
        if (params is not None and 'FailureCriteria' in params):
            criteria = params['FailureCriteria']
            inputFlag = True

        s3 = boto3.resource('s3')
        bucket = s3.Bucket(bucketName)
        matched = {}
        high, medium, low = 0, 0, 0
        data = s3.Object(bucketName, obj)

        body = data.get()['Body'].read()

        endPoint = server_url + "/iac_scan";

        hdrs = {'x-redlock-auth': tokens}
        files = {'templateFile': body}
        r = requests.post(endPoint, files=files, headers=hdrs);

        try:
            parsed_json = json.loads(r.text)

            result = parsed_json.get('result').get('is_successful')
            rules_matched = parsed_json.get('result').get('rules_matched')

            if result:
                if rules_matched is not None:
                    matched[obj] = [rules_matched]
                    display = []
                    for item in rules_matched:
                        details = {"Severity": None, "Name": None, "Files": None}
                        details['Severity'] = item['severity']
                        details['Name'] = item['name']
                        details['Files'] = item['files']
                        display.append(details)

                    stats = parsed_json.get('result').get('severity_stats')
                    high += stats.get("high")
                    medium += stats.get("medium")
                    low += stats.get("low")

            else:
                print("Good job! Prisma Cloud did not detect any issues.")
                put_job_success(job_id, "Success with no issues.")
        except Exception as e:
            print(e)

        list = [high, medium, low]
        decide_job_status(criteria, list, display, job_id, inputFlag)


    except Exception as e:
        print('Putting Job failure', str(e))
        put_job_failure(job_id, str(e))

        raise e
    return "Complete."
