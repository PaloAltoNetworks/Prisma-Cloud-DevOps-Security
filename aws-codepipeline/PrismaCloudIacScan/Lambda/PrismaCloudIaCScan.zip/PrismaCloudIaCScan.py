import json
import boto3
import logging
import urllib
import zipfile
import os
import io
import yaml
from urllib.error import HTTPError
import requests

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
code_pipeline = boto3.client('codepipeline')
configContents = ""

def find_artifact(event):
    try:
        object_key = event['CodePipeline.job']['data']['inputArtifacts'][0] \
            ['location']['s3Location']['objectKey']
        bucket = event['CodePipeline.job']['data']['inputArtifacts'][0] \
            ['location']['s3Location']['bucketName']

        return bucket, object_key

    except KeyError as err:
        raise KeyError("Couldn't get S3 object!\n%s", err)


def _get_user_parameters(job_data):
    try:
        configuration = job_data['actionConfiguration']['configuration']

        if ('UserParameters' not in configuration):
            return

        user_parameters = configuration['UserParameters']
        decoded_parameters = json.loads(user_parameters)
    except Exception as e:
        # We're expecting the user parameters to be encoded as JSON
        # so we can pass multiple values. If the JSON can't be decoded
        # then fail the job with a helpful message.
        raise Exception('UserParameters could not be decoded as JSON')
    return decoded_parameters


def _get_output_artifact_location(job_data):
    location = job_data['outputArtifacts'][0]['location']['s3Location']
    bucket = location['bucketName']
    key = location['objectKey']
    return bucket, key


def put_job_success(job, message):
    """Notify CodePipeline of a successful job

    Args:
        job: The CodePipeline job ID

        message: A message to be logged relating to the job status

    Raises:
        Exception: Any exception thrown by .put_job_success_result()

    """
    if (message is None):
        message = "Good job! Prisma Cloud did not detect any issues."
    print(message)
    #print('Putting job success')
    message = message[:2040]
    code_pipeline.put_job_success_result(jobId=job, executionDetails={"summary": message})


def put_job_failure(job, message):
    """Notify CodePipeline of a failed job

    Args:
        job: The CodePipeline job ID
        message: A message to be logged relating to the job status

    Raises:
        Exception: Any exception thrown by .put_job_failure_result()

    """
    print(message)
    #print('Putting job failure')
    code_pipeline.put_job_failure_result(jobId=job, failureDetails={'message': message, 'type': 'JobFailed'})


def decide_job_status(criteria, statsList, rules_matched, job_id, inputFlag, partial_error):
    """
     Args: criteria -> Input failureCriteria for severity levels
           statsList -> API Response  combined severity level number list for high,medium,low
           rules_matched -> JSON response from API with rules policy , severity, id etc.
           job_id -> CodePipeline job request Id
     Based on Input criteria on severity level count compared with API response stats and Opertor provided in the user parameter,
     Job will be failed or succeeded with JSON failure details
    """
    h, m, l = 0, 0, 0

    operator = 'or'
    if 'High' in criteria:
        h = (criteria['High'])
    if 'Medium' in criteria:
        m = (criteria['Medium'])
    if 'Low' in criteria:
        l = (criteria['Low'])
    if 'Operator' in criteria:
        operator = criteria['Operator']
    failureMsg = """Prisma Cloud IaC scan failed with issues as security issues count (High: {0}, Medium: {1}, Low: {2}) meets or exceeds failure criteria (high: {3}, medium: {4}, low: {5}, operator: {6})""".format(statsList[0], statsList[1], statsList[2], h, m, l, operator)
    succeesWithIssues = """Prisma Cloud IaC scan succeeded with issues as security issues count (High: {0}, Medium: {1}, Low: {2}) below failure criteria (high: {3}, medium: {4}, low: {5}, operator: {6})""".format( statsList[0], statsList[1], statsList[2], h, m, l, operator)

    if (rules_matched is not None):
        if (inputFlag):
            if (operator == 'or') and (statsList[0] >= h or statsList[1] >= m or statsList[2] >= l):
                print(failureMsg)
                put_job_failure(job_id, json.dumps(failureMsg, indent=2))
            elif (operator == 'and') and (statsList[0] >= h and statsList[1] >= m and statsList[2] >= l):
                print(failureMsg)
                put_job_failure(job_id, json.dumps(failureMsg, indent=2))
            else:
                print(succeesWithIssues)
                put_job_success(job_id, json.dumps(succeesWithIssues))
        else:
            put_job_success(job_id, json.dumps(rules_matched))
    else:
        print("Good job! Prisma Cloud did not detect any issues.")
        put_job_success(job_id, "Success with no issues.")

def getTokenFromLoginService(job_id, host, accessKey, secretKey):
    login_url = host + "/login"

    body = {
        "username": accessKey,
        "password": secretKey

    }
    res = urllib.request.Request(login_url, json.dumps(body).encode('utf-8'))
    res.add_header('Content-type', 'application/json')
    res.add_header('user-agent', 'AWS-CodePipeline-Lambda/2.0.0')

    try:
        response = urllib.request.urlopen(res).read()  # .decode('utf-8')
        tokens = (json.loads(response)).get('token')
        print(tokens)
        return tokens


    except urllib.error.HTTPError as ex:
        print('Error code in HTTPErr: ', ex.code, ex.reason, ex.msg)
        if ex.code == 400 or ex.code == 401:
            print(
                "Invalid credentials please verify that API URL, Access Key and Secret Key in Prisma Cloud Extension environment settings are valid For details refer to https://docs.paloaltonetworks.com/prisma/prisma-cloud/prisma-cloud-admin/prisma-cloud-devops-security/use-the-prisma-cloud-extension-for-aws-codepipeline.html")
            put_job_failure(job_id, str(ex))
        if ex.code == 500 or ex.code == 403:
            print(
                "Oops! Something went wrong, please try again or refer to documentation here documentation https://docs.paloaltonetworks.com/prisma/prisma-cloud/prisma-cloud-admin/prisma-cloud-devops-security/use-the-prisma-cloud-extension-for-aws-codepipeline.html")
            put_job_failure(job_id, str(ex))



def lambda_handler(event, context):
    try:
        print('event', event)
        print('context', context)
        job_id = event['CodePipeline.job']['id']
        account_id = event['CodePipeline.job']['accountId']
        function_name = event['CodePipeline.job']['data']['actionConfiguration']['configuration']['FunctionName']
        stage_name = event['CodePipeline.job']['data']['inputArtifacts'][0]['name']
        print("jobID:", job_id)
        server_url = os.environ['Prisma_Cloud_API_URL']
        accesskey = os.environ['Access_Key']
        secretKey = os.environ['Secret_Key']
        asset_name = os.environ['Asset_Name']
        print('asset_name: ', asset_name)
        if (asset_name is None):
            put_job_failure(job_id, json.dumps("Please define Asset name in the lambda environment variables. "
                                               "Environment variable name: Asset_Name"))

        job_data = event['CodePipeline.job']['data']
        params = _get_user_parameters(job_data)
        print("params", params)

        criteria = ''
        inputFlag = False

        bucketName, obj = find_artifact(event)
        if (params is not None and 'FailureCriteria' in params):
            criteria = params['FailureCriteria']
            inputFlag = True

        task_tags = ''
        if (params is not None and 'Tags' in params):
            task_tags = params['Tags']

        s3 = boto3.resource('s3')
        bucket = s3.Bucket(bucketName)
        matched = {}
        high, medium, low = 0, 0, 0
        data = s3.Object(bucketName, obj)
        print('data: ', data.get())
        print('obj', obj)
        body = data.get()['Body'].read()

        content_length = data.get()['ContentLength']
        print('content_length', content_length)
        file_size_limit = 1000000  # 5MB

        if content_length > file_size_limit:
            print("The compressed content file size " + str(content_length) + " exceeds 2MB limit.")
            put_job_failure(job_id, json.dumps("Prisma Cloud IaC scan Directory size more than 5MB is not supported"))
            return

        tokens = getTokenFromLoginService(job_id, server_url, accesskey, secretKey)

        obj_zip = bucket.Object(obj)
        print('obj_zip', obj_zip)
            
        hdrs = {'x-redlock-auth': tokens}
        hdrs["user-agent"] = str("AWS-CodePipeline-Lambda/2.0.0")
        pipeline_name = obj.split('/')[0]
        action_name = obj.split('/')[1]
        repo_tags, endpoint = readConfigFileAndFormHeaders(readPrismaContents(obj_zip), server_url, hdrs, "project_name")
        iac_meta_data = formMetadataObject(asset_name, account_id, function_name, repo_tags, task_tags, "project_name", pipeline_name, job_id, stage_name, action_name, (criteria['High']), (criteria['Medium']), (criteria['Low']), (criteria['Operator']))
        hdrs["x-redlock-iac-metadata"] = str(iac_meta_data)
        files = {'templateFile': body}
        r = requests.post(endpoint, files=files, headers=hdrs)

        try:
            parsed_json = json.loads(r.text)
            print('prased_json', parsed_json)
            result = parsed_json.get('result').get('is_successful')
            rules_matched = parsed_json.get('result').get('rules_matched')
            partial_error = parsed_json.get('result').get('partial_failure')
            print('partial_error', partial_error)
            display = []
            if result:
                if rules_matched is not None:
                    matched[obj] = [rules_matched]
                    for item in rules_matched:
                        details = {"Severity": None, "Name": None, "Files": None}
                        details['Severity'] = item['severity']
                        details['Name'] = item['name']
                        details['Files'] = item['files']
                        display.append(details)

                    stats = parsed_json.get('result').get('severity_stats')
                    high += stats.get("high")
                    medium += stats.get("medium")
                    low += stats.get("low")

                    list = [high, medium, low]
                    if (partial_error is not None):
                        display.append(partial_error)
                    decide_job_status(criteria, list, display, job_id, inputFlag, partial_error)

                else:
                    print("Good job! Prisma Cloud did not detect any issues.")
                    put_job_success(job_id, "Success with no issues.")

            else:
                error_message = parsed_json.get('result').get('error_details')
                put_job_failure(job_id, json.dumps(error_message))
        except Exception as e:
            print("Exception occured", e)
            exception_message = "Oops! Something went wrong, please try again or refer to documentation here documentation https://docs.paloaltonetworks.com/prisma/prisma-cloud/prisma-cloud-admin/prisma-cloud-devops-security/use-the-prisma-cloud-extension-for-aws-codepipeline.html"
            put_job_failure(job_id, exception_message)

    except Exception as e:
        print('Putting Job failure', str(e))
        put_job_failure(job_id, str(e))
        raise e
    return "Complete."

def readPrismaContents(obj_zip):
    with io.BytesIO(obj_zip.get()["Body"].read()) as tf:
        # rewind the file
        tf.seek(0)
        # Read the file as a zipfile and process the members
        with zipfile.ZipFile(tf, mode='r') as zipf:
            for subfile in zipf.namelist():
                if (subfile == ".prismaCloud/config.yml"):
                    print("config.yml", subfile)
                    with zipf.open(subfile) as myfile:
                        configcontents = myfile.read()
                        print(myfile.read())
    print ("contents: ", configcontents)
    return configcontents
                        

def readConfigFileAndFormHeaders(stream, host_url, hdrs, project_name):
    template_type_exists=False
    repo_tags = []

    if (stream != ""):
        print("/.prismaCloud/config.yml exists")
        try:
                yml_loaded = yaml.safe_load(stream)
                config_json_dump = json.dumps(yml_loaded)
                print(config_json_dump)
                config_data = json.loads(config_json_dump)

                if ('template_type' in config_data):
                    template_type_exists=True
                    template_type = config_data["template_type"]
                    if (template_type is not None):
                        template_type = template_type.upper()
                        print(template_type)
                        if (template_type == "TF"):
                            iac_scan_url = host_url+"/iac/tf/v1/scan"
                            if ("terraform_version" in config_data):
                                terraform_version = config_data["terraform_version"]
                                print(terraform_version)
                                if (terraform_version == 0.12):
                                    hdrs["terraform-version"] = str(terraform_version)
                                    print("tf 12")
                                    if ('terraform_012_parameters' in config_data):
                                        print("terraform_012_parameters exists")
                                        terraform_012_parameters = config_data["terraform_012_parameters"]
                                        print(terraform_012_parameters)
                                        if (terraform_012_parameters is not None):
                                            hdrs["terraform-012-parameters"] = str(terraform_012_parameters).replace("root_module", "root-module") #replace underscopr with - as API only understands - headers
                                else:
                                    print("tf 11")
                                    hdrs["terraform-version"] = str(0.11)
                                    if ("terraform_011_parameters" in config_data):
                                        terraform_011_parameters = config_data["terraform_011_parameters"]
                                        print("whole tf 11 params: " + str(terraform_011_parameters))
                                        if (terraform_011_parameters is not None):
                                            if ("variable_files" in terraform_011_parameters):
                                                variable_file_names = config_data["terraform_011_parameters"]["variable_files"]
                                                hdrs["rl-variable-file-names"] = str(variable_file_names)
                                            if ("variable_values" in terraform_011_parameters):
                                                variable_values = config_data["terraform_011_parameters"]["variable_values"]
                                                hdrs["rl-parameters"] = str(variable_values)
                        elif (template_type == "CFT"):
                            print("Template type = CFT")
                            iac_scan_url = host_url + "/iac/cft/v1/scan"
                            if ("cft_parameters" in config_data):
                                cft_parameters = config_data["cft_parameters"]
                                print("cft params:" + str(cft_parameters))
                                if (cft_parameters is not None):
                                    if ("variable_values" in cft_parameters):
                                        variable_values = config_data["cft_parameters"]["variable_values"]
                                        print(variable_values)
                                        hdrs["rl-parameters"] = str(variable_values)
                        elif (template_type == "K8S"):
                            print("Template type = K8S")
                            iac_scan_url = host_url + "/iac/k8s/v1/scan"
                        else:
                            template_type_exists = False
                            raise Exception("No valid template type in config file, valid string")
                    else:
                        template_type_exists = False
                        raise Exception("No valid template type in config file")
                else:
                    template_type_exists=False
                    raise Exception("template_type key exists but not value")

                if ('tags' in config_data):
                    repo_tags = config_data["tags"]
                    print("config labels from config.yml: "+ str(repo_tags))
        except Exception as e:
            print("Error reading or parsing config.yml file: " + str(e))
            if not template_type_exists:
                errMsg='<html><body><p style =\"color:Tomato;\">Prisma Cloud IaC scan</p> <p style=\"color:Tomato;\"> No valid template-type found in config.yml file in repo '+project_name+'. Please specify either of these values: TF, CFT or K8s as template-type variable in the config.yml at the root of your repo under .prismaCloud folder.</p></body></html>'
                raise Exception(errMsg)
            else:
                errMsg='<html><body><p style="color:Tomato;">Prisma Cloud IaC scan</p> <p style="color:Tomato;">Please make sure the config.yml is present in correct format <a href="' + doc_link + '">here</a> at the root of your repo under .prismaCloud folder.</p></body></html>'
                raise Exception(errMsg)
    else:
        print("/.prismaCloud/config.yml is missing")
        errorMsg='<html><body><p style="color:Tomato;">Prisma Cloud IaC scan</p> <p style="color:Tomato;"> Can not find config.yml under .prismaCloud folder in repo ' + project_name + '. Please make sure the file is present in correct format <a href="' + doc_link + '">here</a> at the root of your repo under .prismaCloud folder.</p></body></html>'
        raise Exception(errorMsg)

    return repo_tags, iac_scan_url


def formMetadataObject(asset_name, account_id, function_name, repo_tags, task_tags, project_name, pipeline_name, job_id, stage_name, action_name, failure_criteria_high, failure_criteria_med, failure_criteria_low, failure_criteria_op):
    meta_data_object = {}
    meta_data_object["asset-name"] = asset_name
    meta_data_object["asset-type"] = "GitLab"
    meta_data_object["user-id"] = account_id

    prisma_tags = {}
    settingsTags = os.environ['Tags']
    if (settingsTags is not None):
        settings_tags = settingsTags.split(',')
        print('settingsTags', settings_tags)

    prisma_tags["settings-tags"] = settings_tags
    if (repo_tags is not None):
        prisma_tags["repo-tags"] = repo_tags

    print('taskTags', task_tags)
    if (task_tags != ''):
        prisma_tags["task-tags"] = task_tags

    meta_data_object["prisma-tags"] = prisma_tags

    scan_attr_obj= {}
    # scan_attr_obj["project-name"] = project_name

    pipeline_details = {}
    pipeline_details["lambda-name"] = function_name
    pipeline_details["pipeline-name"] = pipeline_name
    pipeline_details["job-id"] = job_id
    pipeline_details["stage-name"] = stage_name
    pipeline_details["action-name"] = action_name

    scan_attr_obj["pipeline-details"] = pipeline_details

    failure_criteria_obj = {}
    failure_criteria_obj["high"] = failure_criteria_high
    failure_criteria_obj["medium"] = failure_criteria_med
    failure_criteria_obj["low"] = failure_criteria_low
    failure_criteria_obj["op"] = failure_criteria_op

    meta_data_object["scan-attributes"] = scan_attr_obj
    meta_data_object["failure-criteria"] = failure_criteria_obj
    print("final metadata object")
    print(meta_data_object)
    return meta_data_object


